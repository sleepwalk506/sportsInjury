package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.Result;
import com.huali.sportsinjuryandrecovery.pojo.User;
import com.huali.sportsinjuryandrecovery.pojo.UserImage;
import com.huali.sportsinjuryandrecovery.pojo.UserRequest;
import com.huali.sportsinjuryandrecovery.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController

public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value = "/users",method = RequestMethod.GET)
    public Result list(){
        log.info("search all users‘ info");

        //调用service查询用户数据
        List<User> usersList = userService.list();
        return Result.success(usersList);
    }

//    @RequestMapping(value = "/user/userIdList",method = RequestMethod.POST)
//    @PostMapping
//    public ResponseEntity<Result> getUserIdList(){
//        log.info("get user id list");
//
//    }

    @RequestMapping(value = "/user/getUserBlog",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getUserOnlyById(@RequestBody User user){
        log.info("get user blog view");
        String userId = user.getUserId();
        User u = userService.getUserOnlyById(userId);

        if(u != null){
            return ResponseEntity.ok(Result.success(u));
        }
        else{
            return ResponseEntity.ok(Result.error("get user failed"));
        }
    }

    @RequestMapping(value = "/user",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getUserById(@RequestBody UserRequest userRequest){
        log.info("search user by userId");
        String userId = userRequest.getUserId();
        String password = userRequest.getPassword();
        User user = userService.getUserById(userId,password);

        if(user != null){
            return ResponseEntity.ok(Result.success(user));
        }
        else{
            return ResponseEntity.ok(Result.error("login failed"));
        }
    }

    @RequestMapping(value = "/user/update",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> editUserInfo(@RequestBody User user){
        log.info("search user by userId");
//        String userId,String password,int gender,Double height,Double weight,String phoneNumber,String Email
        String userId = user.getUserId();
        String password = user.getPassword();
        int gender = user.getGender();
        Double height = user.getHeight();
        Double weight = user.getWeight();
        String phoneNumber = user.getPhoneNumber();
        String Email = user.getEmail();
        int updatedUser = userService.editUserInfo(userId,password,gender,height,weight,phoneNumber,Email);
        if(updatedUser != 0){
            return ResponseEntity.ok(Result.success(updatedUser));
        }
        else{
            return ResponseEntity.ok(Result.error("update failed"));
        }
    }

    @RequestMapping(value = "/user/register",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> addNewUser(@RequestBody UserRequest userRequest){
        log.info("user register");
        String userId = userRequest.getUserId();
        String password = userRequest.getPassword();
        User user = userService.getUserOnlyById(userId);
        if(user != null){
            return ResponseEntity.ok(Result.error("this user id has been used,please change a user id"));
        }
        else{
            int ifSuccessAddNewUser = userService.addNewUser(userId,password);
            if(ifSuccessAddNewUser == 1){
                User responseUser = userService.getUserById(userId,password);
                return ResponseEntity.ok(Result.success(responseUser));
            }
            else{
                return ResponseEntity.ok(Result.error("user register failed"));
            }
        }
    }

    @RequestMapping(value = "/user/getUserImage",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getUserImage(@RequestBody UserImage userImage){
        log.info("get user image");
        String userId = userImage.getUserId();
        UserImage u = userService.getUserImage(userId);
        if(u != null){
            return ResponseEntity.ok(Result.success(u));
        }
        else{
            return ResponseEntity.ok(Result.error("get user image failed"));
        }
    }

    @RequestMapping(value = "/user/updateUserImage",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> updateUserImage(@RequestBody UserImage userImage){
        log.info("update user image");
        String userId = userImage.getUserId();
        String imageUrl = userImage.getImageUrl();
        int i = userService.updateUserImage(userId,imageUrl);
        if(i != 0){
            UserImage userImage1 = userService.getUserImage(userId);
            return ResponseEntity.ok(Result.success(userImage1));
        }
        else{
            return ResponseEntity.ok(Result.error("update user image failed"));
        }
    }
}
