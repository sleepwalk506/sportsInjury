package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.Blog;
import com.huali.sportsinjuryandrecovery.pojo.Result;
import com.huali.sportsinjuryandrecovery.pojo.User;
import com.huali.sportsinjuryandrecovery.pojo.Message;
import com.huali.sportsinjuryandrecovery.service.MessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.sql.Time;

@Slf4j
@RestController
public class ChatController {
    @Autowired
    private MessageService messageService;

    @RequestMapping(value = "/chat",method = RequestMethod.POST)
    public ResponseEntity<Result> messageList(@RequestBody User user){
        log.info("get all messages");
        String userId = user.getUserId();
        List<Message> messageList = messageService.getMessagesById(userId);
        if(messageList != null){
            return ResponseEntity.ok(Result.success(messageList));
        }
        else{
            return ResponseEntity.ok(Result.error("get messages failed"));
        }
    }
    @RequestMapping(value = "/chat/send",method = RequestMethod.POST)
    public ResponseEntity<Result> sendMessages(@RequestBody Message message){
        log.info("send your messages");
        String messageId = message.getMessageId();
        String senderId = message.getSenderId();
        String receiverId = message.getReceiverId();
        String content = message.getContent();
        String messageTime = message.getMessageTime();
//        System.out.println(messageId+content);
        int updatedMessages = messageService.sendMessages(messageId, senderId, receiverId, messageTime, content);
        if(updatedMessages != 0){
            return ResponseEntity.ok(Result.success(updatedMessages));
        }
        else{
            return ResponseEntity.ok(Result.error("update msg failed"));
        }
    }
}
