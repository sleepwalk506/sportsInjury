/* eslint-disable */
<template>
    <el-input v-model="message"></el-input>
    <el-button @click="send"></el-button>
  </template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { diseaseData, positionData } from '@/data/injury'
const message = ref('')
onMounted: {
  console.log('你好，我是你的AI医生，有什么需要帮助的？')
}
const send = function () {
  console.log(message.value)
  reply()
}
const reply = function () {
  const quest = message.value

  const r_how = /怎么/
  const r_why = /为什么|原因|什么导致|什么会导致/
  const r_what = /什么/
  const r_whatis = /什么是|是什么/
  const r_performance = /表现|现象|症状|表征/
  const r_howtodo = /怎么办|怎么做|怎么处理|治疗/
  const r_hurt = /疼|痛|病/
  let get_disease_flag = false
  // 根据疾病名查询疾病
  for (const diseaseKey in diseaseData) {
    const disease = diseaseData[diseaseKey]
    const r_disease = new RegExp(diseaseKey)
    let flag = false

    if (r_disease.test(quest)) {
      get_disease_flag = true
      if (r_whatis.test(quest)) {
        console.log(disease.description)
        flag = true
      }
      if (r_why.test(quest)) {
        console.log(disease.reason)
        flag = true
      }
      if (r_performance.test(quest)) {
        console.log(disease.performance)
        flag = true
      }
      if (r_howtodo.test(quest)) {
        console.log(disease.treatment)
        flag = true
      }
      if (!flag) {
        console.log(disease.description)
        console.log(disease.reason)
        console.log(disease.performance)
        console.log(disease.treatment)
      }
      return
    }
  }
  // 根据部位查询疾病
  if (r_hurt.test(quest)) {
    let quest_position = ''
    const diseases = []
    for (const positionsKey in positionData) {
      for (const positionKey in positionData[positionsKey]) {
        // 查询quest中的部位
        const position = positionData[positionsKey][positionKey]
        const r_position = new RegExp(position, 'g')
        if (r_position.test(quest)) {
          const matches = quest.match(r_position)
          if (matches) {
            for (const m of matches) {
              if (m != '') { quest_position = m }
            }
          }
          for (const diseaseKey in diseaseData) {
            if (r_position.test(diseaseKey)) { diseases.push(diseaseKey) }
          }
          if (diseases.length > 0) {
            get_disease_flag = true
            const diseaseString = diseases.join('、')
            if (diseases.length == 1) {
              console.log(quest_position + '疼痛可能与' + diseaseString + '有关。')
            } else {
              console.log(quest_position + '疼痛的原因有很多。可能与' + diseaseString + '等疾病有关。')
            }
          }
        }
      }
    }
    if (!get_disease_flag) {
      if (quest_position != '') { console.log('抱歉，' + quest_position + '疼痛不是我擅长领域。请去医院找专业的医生咨询。') } else { console.log('抱歉，您所咨询的疾病不是我擅长领域。请去医院找专业的医生咨询。') }
    }

    return
  }

  if (!get_disease_flag) {
    console.log('抱歉，我没明白您的意思。我是AI医生，如果有关于疾病的问题可以向我提问。')
  }
}
</script>

  <style scoped>

  </style>
