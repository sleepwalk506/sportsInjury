<template>
  <div class="inquiry-view">
    <div class="inquiry-card">
      <div ref="sceneContainer" class="scene-container">
        <el-card v-if="showTooltip || isHovered || isHovered2 " class="tooltip" v-bind:style="{ left: tooltipPosition.x + 'px', top: tooltipPosition.y + 'px' }" @mouseenter="isHovered = true,isHovered2=false" @mouseleave="isHovered = false">
          <template #header>
            <div v-if="currentPart[0].injurySubType == null" class="tooltip-title">
              <span>{{ currentPart[0].injuryType }}</span>
            </div>
            <div v-else class="tooltip-title">
              <el-select v-model="selectedInjuryIndex" class="m-2" placeholder="select" size="large" @visible-change="isHovered2 = true">
                <el-option
                  v-for="(item, index) in currentPart "
                  :key="index"
                  :label="item.injurySubType"
                  :value="index"
                />
              </el-select>
            </div>
          </template>
          <div class="tooltip-description">
            {{ formatDescription(currentPart[selectedInjuryIndex].injuryDescription) }}
          </div>
        </el-card>
        <el-button @click="goBack">Back to Main Menu</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import * as THREE from 'three'
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { ElMessageBox } from 'element-plus'
import axios from 'axios'

const getModelNameFromPath = (path) => {
  const parts = path.split('/')
  return parts[parts.length - 1].split('.')[0]
}

export default {
  name: 'InquiryView',
  setup () {
    const apiUrl = 'http://localhost:8082/injuryInquiry'
    const sceneContainer = ref(null)
    const tooltipPosition = ref({ x: 0, y: 0 })
    let scene, camera, renderer, model, controls
    const showTooltip = ref(false)
    const selectedInjuryIndex = ref('')
    const isHovered = ref(false)
    const isHovered2 = ref(false)
    const currentPart = ref({})
    const showInjurySubTypes = ref(false) // �����Ƿ���ʾ injurySubTypes �б�
    const models = ['/humanModel/Ankle Joint.obj', '/humanModel/Elbow Joint.obj', '/humanModel/Foot.obj', '/humanModel/Forearm.obj', '/humanModel/hand.obj', '/humanModel/Head.obj', '/humanModel/Knee.obj', '/humanModel/Lower Leg.obj', '/humanModel/Lumbar Vertebrae.obj', '/humanModel/Neck.obj', '/humanModel/Sacrum and Coccyx.obj', '/humanModel/Shoulder.obj', '/humanModel/Thigh.obj', '/humanModel/Thoracic Vertebrae.obj', '/humanModel/Upper Limbs.obj', '/humanModel/Wrist.obj']

    const initScene = () => {
      scene = new THREE.Scene()
      camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
      renderer = new THREE.WebGLRenderer({ alpha: true })
      renderer.setSize(window.innerWidth, window.innerHeight)
      // ʹ�ñ����洢 DOM Ԫ�أ������β�ѯ
      const container = sceneContainer.value
      container.appendChild(renderer.domElement)
      // �������ƽ�й�
      const leftDirectionalLight = new THREE.DirectionalLight(0xffffff, 2.5)
      leftDirectionalLight.position.set(-1, 1, 0) // ���������
      scene.add(leftDirectionalLight)

      // �����Ҳ�ƽ�й�
      const rightDirectionalLight = new THREE.DirectionalLight(0xffffff, 2.5)
      rightDirectionalLight.position.set(1, 1, 0) // ���Ҳ�����
      scene.add(rightDirectionalLight)

      const loader = new OBJLoader()
      models.forEach(modelpath => {
        loader.load(modelpath, (object) => {
          model = object
          // ����ģ�͵�����
          model.name = getModelNameFromPath(modelpath)
          // console.log(model.name)
          // ����ģ�͵Ĳ���
          model.traverse((child) => {
            if (child instanceof THREE.Mesh) {
              // �����Ӷ��������
              child.name = modelpath.split('/')[2].split('.')[0]
              // �����Ӷ���Ĳ���
              child.material = new THREE.MeshStandardMaterial({ color: 0xffffff })
            }
          })
          // ����ģ�͵Ĵ�С
          model.scale.set(2, 2, 2)
          // ����ģ�͵�λ��
          model.position.set(0, -1, 0)
          // ��ģ�����ӵ�������
          scene.add(model)
        }
        )
      })
      camera.position.z = 5

      controls = new OrbitControls(camera, renderer.domElement)

      container.addEventListener('mousemove', onMouseMove)

      const animate = () => {
        requestAnimationFrame(animate)
        controls.update()
        renderer.render(scene, camera)
      }
      animate()
    }

    const onMouseMove = async (event) => {
      // ����һ������Ͷ����
      const raycaster = new THREE.Raycaster()
      // ����һ�� Three.js ��������ʾ���λ��
      const mouse = new THREE.Vector2()
      // ������ʾ���λ��
      console.log('1:', isHovered.value)
      console.log('2:', isHovered2.value)
      if (!isHovered.value) tooltipPosition.value = { x: event.offsetX, y: event.offsetY }
      // �����λ��ת��Ϊ��׼���豸����
      mouse.x = (event.offsetX / window.innerWidth) * 2 - 1
      mouse.y = -(event.offsetY / window.innerHeight) * 2 + 1

      // ��������Ͷ��������ʼ��ͷ��򣬻������λ�ú������
      raycaster.setFromCamera(mouse, camera)

      // ��������Ƿ���ģ���ཻ
      const intersects = raycaster.intersectObjects(scene.children, true)
      if (intersects.length > 0) {
        const currentDesc = { injuryType: intersects[0].object.name }
        try {
          const response = await axios.post(apiUrl, currentDesc)
          currentPart.value = response.data.data
          selectedInjuryIndex.value = 0
          // currentPart.value.injuryDescription = response.data.data[0].injuryDescription
          // currentPart.value.injurySubType = response.data.data[0].injurySubType
          // console.log(currentPart.value)
        } catch (error) {
          console.error(error.response)
        }
        showTooltip.value = true
      } else {
        showTooltip.value = false
      }
    }
    const router = useRouter()
    const goBack = () => {
      router.push('/main')
    }

    onMounted(() => {
      initScene()
    })
    const formatDescription = (description) => {
      const wordsPerLine = 5 // ÿ5�����ʲ���һ�����з�
      const words = description.split(/\s+/) // ʹ���������ʽ���ı��ָ�Ϊ��������
      // ���뻻�з���λ��
      for (let i = wordsPerLine; i < words.length; i += wordsPerLine + 1) {
        words.splice(i, 0, '\n')
      }
      return words.join(' ') // ��������������Ϊ�ַ���
    }
    return {
      sceneContainer,
      showTooltip,
      currentPart,
      goBack,
      tooltipPosition,
      formatDescription,
      isHovered,
      isHovered2,
      selectedInjuryIndex
    }
  }
}
</script>

<style scoped>
.inquiry-view {
  background-color: white;
  color: #fff;
  text-align: center;
  font-size: 18px;
  padding: 20px;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.inquiry-card {
  background-color: white;
  padding: 20px;
  border-radius: 10px;
}

.scene-container {
  position: relative;
}
.tooltip-title {
  font-weight: bold; /* �Ӵֱ����ı� */
  font-size: 18px; /* �������������С */
}

.tooltip-description {
  font-size: 16px;
  word-wrap: break-word; /* �������ʻ��� */
  white-space: pre-line; /* �����ո�ͻ��з� */
}
.tooltip {
  position: absolute;
  background-color: #f0f0f0; /* ����ɫ���� */
  color: #333; /* �ı���ɫ */
  border: 1px solid #a0a0a0; /* ǳ��ɫ�߿� */
  border-radius: 10px; /* Բ�� */
  padding: 10px; /* �ڱ߾� */
  font-size: 16px; /* �����С */
}
.m2 {
  font-weight: bold !important; /* �Ӵֱ����ı� */
  font-size: 18px !important; /* �������������С */
  color: black !important; /* ������ɫΪ��ɫ */
  background-color: #f0f0f0 !important; /* ǳ��ɫ���� */
  padding: 10px !important; /* �ڱ߾� */
  border-radius: 5px !important; /* Բ�� */
}
</style>
