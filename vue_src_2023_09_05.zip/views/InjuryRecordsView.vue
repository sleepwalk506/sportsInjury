<template>
  <div class="injury-page">
    <div class="injury-list">
      <div v-for="injury in injuries" :key="injury.recordId" class="injury">
        <h2>{{ injury.title }}</h2>
        <p>{{ injury.detailedDescription }}</p>
      </div>
    </div>

    <div class="back-to-main-button-injury" @click="navigateToMain">
      <i class="el-icon-arrow-left">main</i>
    </div>

    <div class="refresh-button-injury" @click="refreshPage">
      <i class="el-icon-refresh">refresh</i>
    </div>

    <router-link to="/addinjury" class="add-injury-button">
      <span>+</span>
    </router-link>
  </div>
</template>

<script>
import axios from 'axios'
import { mapState } from 'vuex'
import store from '@/store'

export default {
  // computed: {
  //   ...mapState(['injuries'])
  // },
  data () {
    const injuries = []
    const posts = []
    return {
      searchQuery: '',
      userInfo: {
        imageUrl: this.imageUrl,
        userId: this.$store.state.userData.userId,
        password: this.$store.state.userData.password,
        gender: null,
        height: this.$store.state.userData.height,
        weight: this.$store.state.userData.weight,
        age: this.$store.state.userData.age,
        phoneNumber: this.$store.state.userData.phoneNumber,
        email: this.$store.state.userData.email
      },
      injuries
    }
  },
  refreshPage () {
    this.fetchInjuryData()
  },
  created () {
    // Fetch initial injury data when the page is loaded
    this.fetchInjuryData()
  },
  methods: {
    navigateToMain () {
      this.$router.push('/main')
    },
    // formatDate (dateString) {
    //   // Implement date formatting logic here
    // },
    // async searchByInjury () {
    //   // Implement search by injury type logic here
    // },
    // async fetchInjuryData () {
    //   // Implement fetching injury data logic here
    // }
    async fetchInjuryData () {
      try {
        const apiUrl = 'http://localhost:8082/description/getById'
        const userId = { userId: this.userInfo.userId }
        const response = await axios.post(apiUrl, userId) // ?? Axios ?? GET ??
        this.injuries = response.data.data // ???????
        console.log(this.injuries)
      } catch (error) {
        console.error('Error fetching injury data:', error)
      }
    }
  }
}
</script>

  <style>
  .injury-page {
    background-image: url('../images/hinata.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    color: white; /* ������ɫ */
    font-family: Arial, sans-serif; /* ������ʽ */
    padding: 20px; /* ҳ���ڱ� ? */
    min-height: 100vh; /* ��С�߶�ռ�� ? �� */
  }

  .header-injury {
    display: flex;
  justify-content: center;
  position: fixed; /* ??????? */
  top: 0; /* ????????? */
  left: 0; /* ????????? */
  width: 100%; /* ?????? */
  background-color: white; /* ???? */
  padding: 10px 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .header-injury h1 {
    font-size: 24px; /* �� ? ����� ? */
    margin: 0; /* ȥ���� ? ��������� ? */
  }

  .search-box-injury {
    display: flex; /* ʹ�� Flex ���� */
    justify-content: center; /* ˮƽ���� */
    margin-top: 20px; /* �� ? �� ? */
  }

  .search-input-injury {
    width: 250px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px; /* ���������� ? */
  }

  .searchButton-injury {
  padding: 8px 16px;
  background-color: #007BFF;
  color: white;
  border: none;
  cursor: pointer;
  }

  .injury-list {
    flex: 3; /* ???????? */
    padding: 20px;
    overflow-y: auto; /* ????? */
    box-sizing: border-box;
    min-height: 100vh;
    display: flex;
  flex-direction: column;
  align-items: center;
  }

  .injury {
    background-color: rgba(255, 255, 255); /* ��͸������ */
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 20px;
    width: calc(33.33% - 20px); /* ������ȣ�һ���� ?3 ? */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    color: #333; /* ������ɫ */
  }

  .injury h2 {
    font-size: 20px; /* �� ? ����� ? */
    margin-top: 0; /* ȥ���� ? ���� ? �� ? */
  }

  .injury p {
    font-size: 16px;
    margin-top: 10px; /* �� ? �� ? */
  }

  .injury-details {
    display: flex;
    justify-content: space-between;
    margin-top: 10px; /* �� ? �� ? */
  }

  .injury-details span {
    font-size: 14px; /* ��ϸ��Ϣ�����С */
  }

  .add-injury-button {
    position: fixed;
    bottom: 20px;
    left: 180px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 60px;
    height: 60px;
    background-color: rgb(196,130,87);
    color: white;
    border-radius: 50%;
    font-size: 20px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    cursor: pointer;
    z-index: 100; /* ?    ?          ?   */
    text-decoration: none;
  }
  .back-to-main-button-injury {
    position: fixed;
    bottom: 20px;
    left: 100px;
    width: 60px;
    height: 60px;
    background-color: rgb(196,130,87);
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 60px;
    cursor: pointer;
    font-size: 15px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  .refresh-button-injury {
    position: fixed;
    bottom: 20px;
    left: 20px;
    width: 60px;
    height: 60px;
    background-color: rgb(196,130,87);
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 60px;
    cursor: pointer;
    font-size: 15px;
  }
  </style>
