<template>
    <div class="user-profile">
      <div class="user-info">
          <div class="user-info-box">
            <div class="avatar-uploader">
              <label
                class="avatar-uploader-label"
                :style="{ backgroundImage: 'url(' + imageUrl + ')' }"
                for="fileInput"
              >
                <input
                  id="fileInput"
                  ref="fileInput"
                  type="file"
                  accept="image/*"
                  style="display: none;"
                  @change="handleFileChange"
                />
              </label>
            </div>
            <div class="info-item">
              <span class="info-label">User ID:</span> {{ userInfo.userId }}
            </div>
            <div class="info-item">
              <span class="info-label">Gender:</span> {{ userInfo.gender }}
            </div>
            <div class="info-item">
              <span class="info-label">Height:</span> {{ userInfo.height }}
            </div>
            <div class="info-item">
              <span class="info-label">Weight:</span> {{ userInfo.weight }}
            </div>
            <div class="info-item">
              <span class="info-label">Age:</span> {{ userInfo.age }}
            </div>
          </div>
      </div>
      <div class="blog-list">
        <div v-for="blog in blogs" :key="blog.id" class="blog-item">
          <div class="blog-content">
            <h3>{{ blog.title }}</h3>
            <p>{{ blog.content }}</p>
          </div>
          <div class="blog-footer">
            <div class="author-info">
              <span class="spacing">Author: {{ blog.author }}</span>
              <span class="spacing">Update Date: {{ blog.updateDate }}</span>
              <span>Injury Type: {{ blog.injuryType }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>

<script>
import axios from 'axios'
import { mapState, mapMutations } from 'vuex'
// import VueUploadComponent from 'vue-upload-component'
export default {
  // components: {
  //   'vue-upload': VueUploadComponent
  // },
  data () {
    return {
      imageUrl: '',
      userInfo: {
        imageUrl: this.imageUrl,
        userId: this.$store.state.userData.userId,
        password: this.$store.state.userData.password,
        gender: null,
        height: this.$store.state.userData.height,
        weight: this.$store.state.userData.weight,
        age: this.$store.state.userData.age,
        phoneNumber: this.$store.state.userData.phoneNumber,
        email: this.$store.state.userData.email
      },
      blogs: [
        {
          id: 1,
          title: 'My Journey to Recovery',
          content: '...',
          author: 'John Doe',
          updateDate: '2023-08-29',
          injuryType: 'Sports Injury'
        },
        {
          id: 1,
          title: 'My Journey to Recovery',
          content: '...',
          author: 'John Doe',
          updateDate: '2023-08-29',
          injuryType: 'Sports Injury'
        },
        {
          id: 1,
          title: 'My Journey to Recovery',
          content: '...',
          author: 'John Doe',
          updateDate: '2023-08-29',
          injuryType: 'Sports Injury'
        },
        {
          id: 1,
          title: 'My Journey to Recovery',
          content: '...',
          author: 'John Doe',
          updateDate: '2023-08-29',
          injuryType: 'Sports Injury'
        }
        // ... �������Ͷ���
      ]
    }
  },
  created () {
    this.getGender()
  },
  methods: {
    getGender () {
      if (this.$store.state.userData.gender === 1) {
        this.userInfo.gender = 'Male'
      } else {
        this.userInfo.gender = 'Female'
      }
    },
    // async handleFileChange (event) {
    //   const selectedFile = event.target.files[0]
    //   if (selectedFile) {
    //     const resizedImage = await this.resizeImage(selectedFile, 100, 100)
    //     this.imageUrl = resizedImage
    //   }
    // },
    openFileInput () {
      this.$refs.fileInput.click() // ���ļ������
    },

    async handleFileChange (event) {
      const selectedFile = event.target.files[0]
      if (selectedFile) {
        const resizedImage = await this.resizeImage(selectedFile, 100, 100)
        this.imageUrl = resizedImage
      }
    },
    async resizeImage (file, width, height) {
      return new Promise((resolve) => {
        const reader = new FileReader()
        reader.onload = (e) => {
          const img = new Image()
          img.src = e.target.result
          img.onload = () => {
            const canvas = document.createElement('canvas')
            canvas.width = width
            canvas.height = height
            const ctx = canvas.getContext('2d')
            ctx.drawImage(img, 0, 0, width, height)
            const resizedDataUrl = canvas.toDataURL(file.type)
            resolve(resizedDataUrl)
          }
        }
        reader.readAsDataURL(file)
      })
    }
  }
}
</script>

  <style>
.user-profile {
  display: flex;
}

.user-info {
  flex: 1; /* �û���Ϣռ��һ�� */
  padding: 20px;
}

.user-info-box {
  padding: 15px;
  border-radius: 10px;
  background-color: #f5f5f5;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s, transform 0.3s;
}

.user-info-box:hover {
  background-color: #ffffff;
  transform: translateY(-5px);
}

.info-item {
  margin-bottom: 10px;
}

.info-label {
  font-weight: bold;
  margin-right: 5px;
}

.blog-list {
  flex: 3; /* �����б�ռ������ */
  padding: 20px;
  overflow-y: auto; /* ���ӹ����� */
  box-sizing: border-box;
}

.blog-item {
  margin-bottom: 20px;
  padding: 15px;
  border-radius: 10px;
  background-color: #f5f5f5;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s, transform 0.3s;
}

.blog-item:hover {
  background-color: #ffffff;
  transform: translateY(-5px);
}
.blog-content {
  margin-bottom: 10px;
}

.blog-footer {
  display: flex;
  flex-direction: column; /* ���Դ�ֱ���� */
  gap: 5px; /* ����֮��ļ�� */
  font-size: 12px;
  color: #888;
  /* margin-right: 10px; */
}
.spacing {
  margin-right: 10px; /* ���Ӽ�� */
}
.avatar-uploader-label {
  display: inline-block;
  width: 100px;
  height: 100px;
  text-align: center;
  line-height: 100px;
  border: 1px dashed #d9d9d9;
  border-radius: 50%; /* Բ����ʽ */
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader-label:hover {
  background-color: #f5f5f5;
}

.avatar {
  width: 100px;
  height: 100px;
  border-radius: 50%;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
  </style>
