<template>
  <div class="chat-page">
    <div class="browse-post-container">
      <div class="header">
        <div class="search-box">
          <input v-model="searchByAuthorQuery" placeholder="search by author..." class="search-input">
          <button @click="searchByAuthor" class="searchButton">search</button>
        </div>
        <div class="search-box">
          <input v-model="searchByInjuryQuery" placeholder="search by injury..." class="search-input">
          <button @click="searchByInjury" class="searchButton">search</button>
        </div>
      </div>
      <div v-for="post in posts" :key="post.id" class="post">
        <h2>{{ post.title }}</h2>
        <p>{{ post.content }}</p>
        <div class="post-details">
          <span>author:{{ post.userId }}</span>
          <span>update date:{{ post.blogDate }}</span>
          <span>injury type:{{ post.injuryType }}</span>
        </div>
      </div>
    </div>
    <router-link to="/userblog" class="post-button">
      <span>+</span>
    </router-link>
    <div class="refresh-button" @click="refreshPage">
      <i class="el-icon-refresh">refresh</i>
    </div>
  </div>
  </template>
<script>
import axios from 'axios'
// import { ref } from 'vuex'
export default {
  data () {
    const posts = []
    // const posts = ref([])
    // const posts = [
    //   {
    //     id: 1,
    //     title: 'How to prevent knee pain after running',
    //     injuryType: 'knee',
    //     content: 'After running, I often feel knee pain. Is there any way to prevent this from happening',
    //     author: 'John Doe',
    //     date: '2023-08-15'
    //   },
    //   {
    //     id: 2,
    //     title: 'Share my experience in the rehabilitation process',
    //     injuryType: 'ankle',
    //     content: 'I went through a recovery process due to an ankle sprain before, and now I have recovered very well. I would like to share my experience with you.',
    //     author: 'Alice Smith',
    //     date: '2023-08-18'
    //   }
    //   // ��������...
    // ]

    return {
      searchByAuthorQuery: '',
      searchQuery: '',
      posts
    }
  },
  created () {
    this.fetchBlogData()
  },
  methods: {
    refreshPage () {
      location.reload()
    },
    async searchByAuthor () {
      try {
        const apiUrl = 'http://localhost:8082/blog/searchByAuthor'
        console.log(this.searchByAuthorQuery)
        const dataToSend = { userId: this.searchByAuthorQuery }
        const response = await axios.post(apiUrl, dataToSend) // Assuming the endpoint is like "/user/{userId}"
        this.posts = response.data.data
        console.log(this.posts)
        // Process userData or update the component's state as needed
      } catch (error) {
        console.error('Error fetching user data:', error)
      }
    },
    async searchByInjury () {
      try {
        const apiUrl = 'http://localhost:8082/blog/searchByInjury'
        console.log(this.searchByInjuryQuery)
        const dataToSend = { injuryType: this.searchByInjuryQuery }
        const response = await axios.post(apiUrl, dataToSend) // Assuming the endpoint is like "/user/{userId}"
        this.posts = response.data.data
        console.log(this.posts)
        // Process userData or update the component's state as needed
      } catch (error) {
        console.error('Error fetching user data:', error)
      }
    },
    async fetchBlogData () {
      try {
        const apiUrl = 'http://localhost:8082/blog'
        const response = await axios.post(apiUrl) // ʹ�� Axios ���� GET ����
        this.posts = response.data.data // �������������
        console.log(this.posts)
      } catch (error) {
        console.error('Error fetching blog data:', error)
      }
    }
  },
  watch: {
    searchQuery: {
      handler: 'getPosts',
      immediate: true
    }
  }
}
</script>
<style>
.chat-page{
  background-image: url('../images/hinata.jpg');
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
}
body {
  margin: 0;
  padding: 0;
  /* background: linear-gradient(to bottom,#ed7104, #df9ba5);
  background-image: url('../images/hinata.jpg'); */
  /* background-size: cover;
  background-position: center;
  background-attachment: fixed; */
}

.browse-post-container {
   /* Բ�Ǳ߿� */
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  min-height: 100vh;
  box-sizing: border-box;
}
.spacer {
  width: 10px; /* �������Ŀ��� */
}
.search-input {
  width: 250px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.search-box {
  display: flex;
  align-items: center;
  margin-right: 10px;
}
.searchButton {
  padding: 8px 16px;
  background-color: #007BFF;
  color: white;
  border: none;
  cursor: pointer;
}
/* .browse-post-container {
  max-width: 800px;
  margin: 0 auto;
  background: linear-gradient(to bottom, #ed7104, #df9ba5);
  padding: 20px;
  min-height: 100vh;
  box-sizing: border-box;
}
*/

.header {
  display: flex;
  justify-content: center;
  position: fixed; /* �̶���ҳ���Ϸ� */
  top: 0; /* ����ҳ�涥���ľ��� */
  left: 0; /* ����ҳ�����ľ��� */
  width: 100%; /* ռ���������� */
  background-color: white; /* ������ɫ */
  padding: 10px 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.post-list {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.post-details span {
  margin-right: 10px; /* Ϊ���ߺ͸�������֮�����Ӽ�� */
}
.post {
  background-color: white;
  border: 1px solid #ccc;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
  width: 80%;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
.post-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 60px;
  height: 60px;
  background-color: rgb(75, 134, 224);
  color: white;
  border-radius: 50%;
  font-size: 20px;
  text-align: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  z-index: 100; /* ȷ����ť����������֮�� */
  text-decoration: none;
}
.refresh-button {
  position: fixed;
  bottom: 20px;
  left: 20px;
  width: 60px;
  height: 60px;
  background-color: rgb(75, 134, 224);
  color: white;
  border-radius: 50%;
  text-align: center;
  line-height: 50px;
  cursor: pointer;
  font-size: 15px;
}
</style>
