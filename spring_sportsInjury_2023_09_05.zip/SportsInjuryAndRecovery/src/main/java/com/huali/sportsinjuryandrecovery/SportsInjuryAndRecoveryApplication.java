package com.huali.sportsinjuryandrecovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsInjuryAndRecoveryApplication {

    public static void main(String[] args) {
        SpringApplication.run(SportsInjuryAndRecoveryApplication.class, args);
    }

}
