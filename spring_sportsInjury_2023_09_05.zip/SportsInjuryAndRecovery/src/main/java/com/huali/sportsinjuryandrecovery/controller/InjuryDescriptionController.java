package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.InjuryDescription;
import com.huali.sportsinjuryandrecovery.pojo.Result;
import com.huali.sportsinjuryandrecovery.pojo.User;
import com.huali.sportsinjuryandrecovery.service.InjuryDescriptionService;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
public class InjuryDescriptionController {
    @Autowired
    private InjuryDescriptionService injuryDescriptionService;

    @RequestMapping(value = "/description/getById",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getInjuryDescriptionList(@RequestBody User user){
        String userId = user.getUserId();
        List<InjuryDescription> injuryDescriptionList = injuryDescriptionService.getInjuryDescriptionList(userId);
        if(injuryDescriptionList == null){
            return ResponseEntity.ok(Result.error("get injury description list failed"));
        }
        else{
            return ResponseEntity.ok(Result.success(injuryDescriptionList));
        }
    }

    @RequestMapping(value = "/description/addNewDescription",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> addInjuryDescription(@RequestBody InjuryDescription injuryDescription){
        String userId = injuryDescription.getUserId();
        String title = injuryDescription.getTitle();
        String descriptionId = injuryDescription.getDescriptionId();
        String detailedDescription = injuryDescription.getDetailedDescription();
        int addSuccess = injuryDescriptionService.addInjuryDescription(userId,descriptionId,title,detailedDescription);
        if(addSuccess == 0){
            return ResponseEntity.ok(Result.error("get injury description list failed"));
        }
        else{
            return ResponseEntity.ok(Result.success(addSuccess));
        }
    }
}
