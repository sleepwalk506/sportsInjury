package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.*;
import com.huali.sportsinjuryandrecovery.service.InjuryRecordsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Slf4j
@RestController
public class InjuryRecordsController {
    @Autowired
    private InjuryRecordsService injuryRecordsService;

    @RequestMapping(value = "/injuryRecords",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getAllInjuryRecordsByUser(@RequestBody User user){
        String userId = user.getUserId();
        List<InjuryRecords> injuryRecordsList = injuryRecordsService.getAllInjuryRecordsByUser(userId);
        if(injuryRecordsList == null){
            return ResponseEntity.ok(Result.error("get injury records failed"));
        }
        else {
            return ResponseEntity.ok(Result.success(injuryRecordsList));
        }
    }

    @RequestMapping(value = "injuryRecords/update",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> updateInjuryRecord(@RequestBody InjuryRecords injuryRecords){
        String recordId = injuryRecords.getRecordId();
        String userId = injuryRecords.getUserId();
        String injuryType = injuryRecords.getInjuryType();
        String injuryPosition = injuryRecords.getInjuryPosition();
        Date dateOfInjury = injuryRecords.getDateOfInjury();
        int recoveryStatus = injuryRecords.getRecoveryStatus();
        String injuryDescription = injuryRecords.getInjuryDescription();
        int updateSuccess = injuryRecordsService.updateInjuryRecord(recordId,userId,injuryType,injuryPosition,dateOfInjury,recoveryStatus,injuryDescription);
        if(updateSuccess == 0){
            return ResponseEntity.ok(Result.error("update injury records failed"));
        }
        else{
            return ResponseEntity.ok(Result.success(updateSuccess));
        }
    }

    @RequestMapping(value = "injuryRecords/searchByType",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getInjuryRecordsByInjuryType(@RequestBody SearchByInjuryType searchByInjuryType){
        String userId = searchByInjuryType.getUserId();
        String injuryType = searchByInjuryType.getInjuryType();
        List<InjuryRecords> injuryRecordsList = injuryRecordsService.getInjuryRecordsByInjuryType(userId,injuryType);
        if(injuryRecordsList == null){
            return ResponseEntity.ok(Result.error("cant find injury record with this type"));
        }
        else{
            return ResponseEntity.ok(Result.success(injuryRecordsList));
        }
    }

    @RequestMapping(value = "injuryRecords/searchByPosition",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getInjuryRecordsByInjuryPosition(@RequestBody SearchByInjuryPosition searchByInjuryPosition){
        String userId = searchByInjuryPosition.getUserId();
        String injuryPosition = searchByInjuryPosition.getInjuryPosition();
        List<InjuryRecords> injuryRecordsList = injuryRecordsService.getInjuryRecordsByInjuryPosition(userId,injuryPosition);
        if(injuryRecordsList == null){
            return ResponseEntity.ok(Result.error("cant find injury record with this type"));
        }
        else{
            return ResponseEntity.ok(Result.success(injuryRecordsList));
        }
    }

    @RequestMapping(value = "injuryRecords/addNewRecord",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> addNewInjuryRecord(@RequestBody InjuryRecords injuryRecords){
        String recordId = injuryRecords.getRecordId();
        String userId = injuryRecords.getUserId();
        String injuryType = injuryRecords.getInjuryType();
        String injuryPosition = injuryRecords.getInjuryPosition();
        Date dateOfInjury = injuryRecords.getDateOfInjury();
        int recoveryStatus = injuryRecords.getRecoveryStatus();
        String injuryDescription = injuryRecords.getInjuryDescription();
        int addSuccess = injuryRecordsService.addNewInjuryRecord(recordId,userId,injuryType,injuryPosition,dateOfInjury,recoveryStatus,injuryDescription);
        if(addSuccess == 0){
            return ResponseEntity.ok(Result.error("add injury record failed"));
        }
        else{
            return ResponseEntity.ok(Result.success(addSuccess));
        }
    }

    @RequestMapping(value = "injuryRecords/deleteRecord",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> deleteInjuryRecord(@RequestBody InjuryRecords injuryRecords){
        String recordId = injuryRecords.getRecordId();
        int deleteSuccess = injuryRecordsService.deleteInjuryRecord(recordId);
        if(deleteSuccess == 0){
            return ResponseEntity.ok(Result.error("delete injury record failed"));
        }
        else{
            return ResponseEntity.ok(Result.success(deleteSuccess));
        }
    }
}
