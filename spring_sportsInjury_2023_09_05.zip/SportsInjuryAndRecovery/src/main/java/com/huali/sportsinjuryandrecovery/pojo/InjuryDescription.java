package com.huali.sportsinjuryandrecovery.pojo;

import lombok.Data;

@Data
public class InjuryDescription {
    String userId;
    String title;
    String descriptionId;
    String detailedDescription;
}
