import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import MainView from '../views/MainView.vue'
import LoginView from '../views/LoginView.vue'
import UserView from '../views/UserView.vue'
import SportsView from '../views/SportsView.vue'
import ChatView from '../views/ChatView.vue'

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/main',
    name: 'main',
    component: MainView
  },
  {
    path: '/user',
    name: 'user',
    component: UserView
  },
  {
    path: '/sportRecord',
    name: 'sportRecord',
    component: SportsView
  },
  {
    path: '/chatAndBlog',
    name: 'chatandblog',
    component: ChatView
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
