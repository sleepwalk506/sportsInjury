package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.Blog;
import com.huali.sportsinjuryandrecovery.pojo.Injury;
import com.huali.sportsinjuryandrecovery.pojo.Result;
import com.huali.sportsinjuryandrecovery.pojo.User;
import com.huali.sportsinjuryandrecovery.service.BlogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
public class BlogController {

    @Autowired
    private BlogService blogService;

    @RequestMapping(value = "/blog",method = RequestMethod.POST)
    public ResponseEntity<Result> blogList(){
        log.info("get all blogs");
        List<Blog> blogList = blogService.blogList();
        if(blogList != null){
            return ResponseEntity.ok(Result.success(blogList));
        }
        else{
            return ResponseEntity.ok(Result.error("get blogs failed"));
        }
    }

    @RequestMapping(value = "/blog/searchByAuthor",method = RequestMethod.POST)
    public ResponseEntity<Result> searchBlogByAuthor(@RequestBody User user){
        String userId = user.getUserId();
//        System.out.println(userId);
        log.info("search blogs by author");
        List<Blog> blogList = blogService.searchBlogByAuthor(userId);
        if(blogList != null){
            return ResponseEntity.ok(Result.success(blogList));
        }
        else{
            return ResponseEntity.ok(Result.error("get blogs failed"));
        }
    }

    @RequestMapping(value = "/blog/searchByInjury",method = RequestMethod.POST)
    public ResponseEntity<Result> searchBlogByInjury(@RequestBody Injury injury){
        String injuryType = injury.getInjuryType();
        log.info("search blogs by injury");
        List<Blog> blogList = blogService.searchBlogByInjury(injuryType);
        if(blogList != null){
            return ResponseEntity.ok(Result.success(blogList));
        }
        else{
            return ResponseEntity.ok(Result.error("get blogs failed"));
        }
    }
}
