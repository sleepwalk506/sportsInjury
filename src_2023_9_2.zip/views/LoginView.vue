<template>
  <div class="login-container">
    <el-card class="login-card">
      <h2 class="login-title">{{ formMode === 'login' ? 'User Login' : 'User Registration' }}</h2>
      <el-form ref="form" :model="formData" :rules="formRules" label-width="80px">
        <el-form-item label="userId" prop="userId">
          <el-input v-model="formData.userId"></el-input>
        </el-form-item>
        <el-form-item label="password" prop="password">
          <el-input type="password" v-model="formData.password"></el-input>
        </el-form-item>
        <el-form-item v-if="formMode === 'register'" label="confirmPassword" prop="confirmPassword">
          <el-input type="password" v-model="formData.confirmPassword"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm">{{ formMode === 'login' ? 'Login' : 'Register' }}</el-button>
          <el-button @click="toggleFormMode">{{ formMode === 'login' ? 'Switch to Register' : 'Switch to Login'
          }}</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import axios from 'axios'
import { mapMutations } from 'vuex'
import { ElMessageBox } from 'element-plus'
export default {
  data () {
    return {
      formMode: 'login', // 'login' or 'register'
      formData: {
        userId: '',
        password: '',
        confirmPassword: ''
      },
      formRules: {
        userId: [{ required: true, message: 'Please input userId', trigger: 'blur' }],
        password: [{ required: true, message: 'Please input password', trigger: 'blur' }],
        confirmPassword: [
          { required: true, message: 'Please confirm password', trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              if (value !== this.formData.password) {
                callback(new Error('Passwords do not match'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    ...mapMutations(['setUser']),
    toggleFormMode () {
      this.formMode = this.formMode === 'login' ? 'register' : 'login'
      this.clearForm()
    },
    clearForm () {
      this.$refs.form.resetFields()
    },
    submitForm () {
      this.$refs.form.validate(valid => {
        if (valid) {
          const apiUrl = this.formMode === 'login' ? 'http://localhost:8082/user' : 'http://localhost:8082/user/register'
          const userData = {
            userId: this.formData.userId,
            password: this.formData.password
          }

          if (this.formMode === 'register') {
            userData.confirmPassword = this.formData.confirmPassword
          }

          axios.post(apiUrl, userData)
            .then(response => {
              console.log(response.data)
              if (response.data.code === 0) {
                if (response.data.msg === 'this user id has been used,please change a user id') {
                  ElMessageBox.alert('this user id has been used,please change a user id', {
                    confirmButtonText: 'OK',
                    type: 'error'
                  })
                } else if (response.data.msg === 'user register failed') {
                  ElMessageBox.alert('user register failed', {
                    confirmButtonText: 'OK',
                    type: 'error'
                  })
                } else {
                  ElMessageBox.alert('User or password is wrong', 'Login Failed', {
                    confirmButtonText: 'OK',
                    type: 'error'
                  })
                }
              } else if (response.data.code === 1) {
                this.setUser(response.data.data)
                console.log(this.$store.state.userData)
                // ���ݷ��ص����ݴ�����¼/ע��ɹ��߼�
                this.$router.push('/main')
              }
              // this.setUser(response.data.data)
              // console.log(this.$store.state.userData)
              // // ���ݷ��ص����ݴ�����¼/ע��ɹ��߼�
              // this.$router.push('/main')
            })
            .catch(error => {
              console.error(error.response.data)
              // ���ݷ��صĴ�������¼/ע��ʧ���߼�
            })
        } else {
          console.log('Form validation failed')
        }
      })
    }
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(to bottom, #000000, #333333);
}

.login-card {
  width: 400px;
  padding: 20px;
  background-color: #222;
  border-radius: 15px;
  color: white;
}

.login-title {
  font-size: 24px;
  margin-bottom: 20px;
  text-align: center;
}
</style>
