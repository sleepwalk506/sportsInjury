package com.huali.sportsinjuryandrecovery.pojo;

import lombok.Data;

@Data
public class LoadFile {
    private String fileName;
    private String fileType;
    private long fileSize;
}
