package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.Result;
import com.huali.sportsinjuryandrecovery.pojo.User;
import com.huali.sportsinjuryandrecovery.pojo.UserRequest;
import com.huali.sportsinjuryandrecovery.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController

public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value = "/users",method = RequestMethod.GET)
    public Result list(){
        log.info("search all users‘ info");

        //调用service查询用户数据
        List<User> usersList = userService.list();
        return Result.success(usersList);
    }

    @RequestMapping(value = "/user",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> getUserById(@RequestBody UserRequest userRequest){
        log.info("search user by userId");
        String userId = userRequest.getUserId();
        String password = userRequest.getPassword();
        User user = userService.getUserById(userId,password);

        if(user != null){
            return ResponseEntity.ok(Result.success(user));
        }
        else{
            return ResponseEntity.ok(Result.error("login failed"));
        }
    }

    @RequestMapping(value = "/user/update",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> editUserInfo(@RequestBody User user){
        log.info("search user by userId");
//        String userId,String password,int gender,Double height,Double weight,String phoneNumber,String Email
        String userId = user.getUserId();
        String password = user.getPassword();
        int gender = user.getGender();
        Double height = user.getHeight();
        Double weight = user.getWeight();
        String phoneNumber = user.getPhoneNumber();
        String Email = user.getEmail();
        int updatedUser = userService.editUserInfo(userId,password,gender,height,weight,phoneNumber,Email);
        if(updatedUser != 0){
            return ResponseEntity.ok(Result.success(updatedUser));
        }
        else{
            return ResponseEntity.ok(Result.error("update failed"));
        }
    }
}
