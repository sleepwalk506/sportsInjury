package com.huali.sportsinjuryandrecovery.controller;

import com.huali.sportsinjuryandrecovery.pojo.Result;
import com.huali.sportsinjuryandrecovery.pojo.SportsRecord;
import com.huali.sportsinjuryandrecovery.pojo.UserRequest;
import com.huali.sportsinjuryandrecovery.service.SportsRecordsService;
import com.huali.sportsinjuryandrecovery.service.impl.SportsRecordsServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
public class SportsRecordsController {
    @Autowired
    private SportsRecordsService sportsRecordsService;

    @RequestMapping(value = "/sportsRecords",method = RequestMethod.POST)
    @PostMapping
    public Result sportsRecordsList(){
        log.info("search all sports records' info");

        List<SportsRecord> sportsRecord = sportsRecordsService.sportsRecordsList();
        return Result.success(sportsRecord);
    }

    @RequestMapping(value = "/sportsRecords/update",method = RequestMethod.POST)
    @PostMapping
    public ResponseEntity<Result> editSportsRecordsInfo(@RequestBody SportsRecord sportsRecord){
        log.info("update sports records");
        String exerciseId = sportsRecord.getExerciseId();
        String exerciseType = sportsRecord.getExerciseType();
        Date exerciseDate = sportsRecord.getExerciseDate();
        Time exerciseTime = sportsRecord.getExerciseTime();
        Double kcal = sportsRecord.getKcal();
        Double avgSpeed = sportsRecord.getAvgSpeed();
        Double avgHeartRate = sportsRecord.getAvgHeartRate();
        System.out.println(exerciseId+exerciseType);
        int updatedSportsRecords = sportsRecordsService.editSportsRecordsInfo(exerciseId,exerciseType,exerciseDate,exerciseTime,kcal,avgSpeed,avgHeartRate);
        if(updatedSportsRecords != 0){
            return ResponseEntity.ok(Result.success(updatedSportsRecords));
        }
        else{
            return ResponseEntity.ok(Result.error("update failed"));
        }
    }
}
