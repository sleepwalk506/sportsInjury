package com.huali.sportsinjuryandrecovery.service;

import com.huali.sportsinjuryandrecovery.pojo.User;

import java.util.List;

public interface UserService {

    List<User> list();
    User getUserById(String userId,String password);
    int editUserInfo(String userId,String password,int gender,Double height,Double weight,String phoneNumber,String Email);
}
