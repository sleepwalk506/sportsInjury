package com.huali.sportsinjuryandrecovery.pojo;

import lombok.Data;

@Data
public class UserRequest {
    private String userId;
    private String password;
}
