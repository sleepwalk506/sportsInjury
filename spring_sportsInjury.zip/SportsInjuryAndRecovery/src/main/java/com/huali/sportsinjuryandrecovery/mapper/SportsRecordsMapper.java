package com.huali.sportsinjuryandrecovery.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.huali.sportsinjuryandrecovery.pojo.SportsRecord;

import java.sql.Time;
import java.util.Date;
import java.util.List;


@Mapper
public interface SportsRecordsMapper {

    List<SportsRecord> sportsRecordList();

    int editSportsRecordsInfo(String exerciseId, String exerciseType, Date exerciseDate, Time exerciseTime, Double kcal, Double avgSpeed, Double avgHeartRate);
}
