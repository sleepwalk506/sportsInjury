// main.ts
import { createApp } from 'vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import App from './App.vue'
import router from './router'
import store from './store'
// import LoginView from './views/LoginView.vue'

// const app = createApp(LoginView)
const app = createApp(App)

app.use(ElementPlus).use(store).use(router)
app.mount('#app')
