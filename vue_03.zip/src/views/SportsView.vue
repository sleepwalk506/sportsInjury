<template>
    <div class="sport-view">
      <el-table :data="exerciseRecords" style="width: 100%">
        <el-table-column label="Exercise Type" prop="exerciseType">
          <template v-slot="scope">
            <template v-if="!scope.row.editing">
              {{ scope.row.exerciseType }}
            </template>
            <template v-else>
              <el-input v-model="scope.row.editData.exerciseType"></el-input>
            </template>
          </template>
        </el-table-column>
        <el-table-column label="Exercise Date" prop="exerciseDate">
          <template v-slot="scope">
            <template v-if="!scope.row.editing">
              {{ scope.row.exerciseDate }}
            </template>
            <template v-else>
              <el-input v-model="scope.row.editData.exerciseDate"></el-input>
            </template>
          </template>
        </el-table-column>
        <el-table-column label="Exercise Time" prop="exerciseTime">
          <template v-slot="scope">
            <template v-if="!scope.row.editing">
              {{ scope.row.exerciseTime }}
            </template>
            <template v-else>
              <el-input v-model="scope.row.editData.exerciseTime"></el-input>
            </template>
          </template>
        </el-table-column>
        <el-table-column label="kcal" prop="kcal">
          <template v-slot="scope">
            <template v-if="!scope.row.editing">
              {{ scope.row.kcal }}
            </template>
            <template v-else>
              <el-input v-model="scope.row.editData.kcal"></el-input>
            </template>
          </template>
        </el-table-column>
        <el-table-column label="AvgSpeed" prop="avgSpeed">
          <template v-slot="scope">
            <template v-if="!scope.row.editing">
              {{ scope.row.avgSpeed }}
            </template>
            <template v-else>
              <el-input v-model="scope.row.editData.avgSpeed"></el-input>
            </template>
          </template>
        </el-table-column>
        <el-table-column label="AvgHeartRate" prop="avgHeartRate">
          <template v-slot="scope">
            <template v-if="!scope.row.editing">
              {{ scope.row.avgHeartRate }}
            </template>
            <template v-else>
              <el-input v-model="scope.row.editData.avgHeartRate"></el-input>
            </template>
          </template>
        </el-table-column>
        <!-- ... ʡ�������� ... -->
        <el-table-column label="Actions">
        <template v-slot="scope">
          <template v-if="!scope.row.editing">
            <el-button @click="editRow(scope.row)">Edit</el-button>
          </template>
          <template v-else>
            <el-button @click="saveRow(scope.row)">Save</el-button>
            <el-button @click="cancelEdit(scope.row)">Cancel</el-button>
          </template>
        </template>
      </el-table-column>
      </el-table>

      <el-button @click="goBack">Back to Main Menu</el-button>
    </div>
  </template>

<script>
import { ref, Vue, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { mapMutations, useStore } from 'vuex'

export default {
  name: 'SportView',
  ...mapMutations(['setSportsRecords']),
  setup () {
    // const backendData = Vue.ref([])
    const apiUrl = 'http://localhost:8082/sportsRecords'
    const store = useStore()
    const exerciseRecords = ref([])
    onMounted(() => {
      // ʹ�� onMounted ����ȷ��������ҳ���״μ��غ󱻳�ʼ��
      axios.post(apiUrl).then(response => {
        console.log(response.data)
        store.commit('setSportsRecords', response.data.data)
        console.log('Updated data:', store.state.sportsRecordsData)

        // ��ʼ�� exerciseRecords ����
        exerciseRecords.value = store.state.sportsRecordsData.map(item => {
          return { ...item, editing: false, editData: {} }
        })
      })
        .catch(error => {
          console.error(error.response.data)
        // ���������߼�
        })
    })
    // const addEditDataToJson = () => {
    //   exerciseRecords.value.array.forEach(item => {
    //     item.editing = false
    //     item.editData = {}
    //   })
    // }

    // const sportsRecordsEditing = Vue.computed(() => {
    //   return store.state.sportsRecordsData.map(item => {
    //     return { ...item, editing: false, editData: {} }
    //   })
    // })
    // const exerciseRecords = ref([
    //   // Your exercise records data here
    //   {
    //     exerciseType: 'Running',
    //     exerciseDate: '2023-08-27',
    //     exerciseTime: '30 minutes',
    //     Kcal: 300,
    //     maxSpeed: '10 km/h',
    //     minSpeed: '5 km/h',
    //     avgSpeed: '8 km/h',
    //     avgHeartRate: 120,
    //     editing: false,
    //     editData: {}
    //   },
    //   {
    //     exerciseType: 'Swimming',
    //     exerciseDate: '2023-08-28',
    //     exerciseTime: '45 minutes',
    //     Kcal: 400,
    //     maxSpeed: '2 km/h',
    //     minSpeed: '1 km/h',
    //     avgSpeed: '1.5 km/h',
    //     avgHeartRate: 100,
    //     editing: false,
    //     editData: {}
    //   }
    // ])

    const editRow = (row) => {
      row.editing = true
      row.editData = { ...row }
    }

    const saveRow = async (row) => {
      if (row.editData) {
        // Update the original row data with the edited values
        const index = exerciseRecords.value.indexOf(row)
        exerciseRecords.value[index] = { ...row.editData }
        // store.commit('setSportsRecords', exerciseRecords)
        row.editData = {}
        row.editing = false
        try {
          await axios.post('http://localhost:8082/sportsRecords/update', exerciseRecords.value[index])
          console.log(exerciseRecords.value[index])
          // ����ɹ������»�ȡ�������
          const response = await axios.post(apiUrl)
          store.commit('setSportsRecords', response.data.data)
          // ���� exerciseRecords
          exerciseRecords.value = store.state.sportsRecordsData.map(item => {
            return { ...item, editing: false, editData: {} }
          })
        } catch (error) {
          console.error(error.response.data)
          // ���������߼�
        }
      }
    }

    // watch(() => store.state.sportsRecordsData, () => {
    //   exerciseRecords.value = store.state.sportsRecordsData.map(item => {
    //     return { ...item, editing: false, editData: {} }
    //   })
    // })

    const exerciseRecordsComputed = computed(() => {
      return store.state.sportsRecordsData.map(item => {
        return { ...item, editing: false, editData: {} }
      })
    })

    // ���� exerciseRecordsComputed �ı仯
    watch(exerciseRecordsComputed, newData => {
      exerciseRecords.value = newData
    })

    const cancelEdit = (row) => {
      row.editData = {}
      row.editing = false
    }

    const router = useRouter()
    const goBack = () => {
      router.push('/main') // ��ת�����˵�ҳ���·��·��
    }
    // initializeData()
    // console.log('exerciseRecords1:', exerciseRecords.value)
    // addEditDataToJson()
    console.log('exerciseRecords2:', exerciseRecords)

    return {
      exerciseRecords,
      editRow,
      saveRow,
      cancelEdit,
      goBack
    }
  }
}
</script>

  <style scoped>
  .sport-view {
    background-color: #f0f0f0; /* Light gray background */
    padding: 20px;
  }
  </style>
