<template>
  <div class="login-container">
    <el-card class="login-card">
      <h2 class="login-title">User Login</h2>
      <el-form ref="loginForm" :model="loginForm" :rules="loginRules" label-width="80px">
        <el-form-item label="userId" prop="userId">
          <el-input v-model="loginForm.userId"></el-input>
        </el-form-item>
        <el-form-item label="password" prop="password">
          <el-input type="password" v-model="loginForm.password"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="login">Login</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import axios from 'axios'
import { mapMutations } from 'vuex'
export default {
  data () {
    return {
      loginForm: {
        userId: '',
        password: ''
      },
      loginRules: {
        userId: [{ required: true, message: 'Please input userId', trigger: 'blur' }],
        password: [{ required: true, message: 'Please input password', trigger: 'blur' }]
      }
    }
  },
  methods: {
    ...mapMutations(['setUser']),
    login () {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          const userData = {
            userId: this.loginForm.userId,
            password: this.loginForm.password
          }

          // ���͵�¼���󵽺��
          const apiUrl = 'http://localhost:8082/user'
          axios.post(apiUrl, userData)
            .then(response => {
              console.log(response.data)
              this.setUser(response.data.data)
              console.log(this.$store.state.userData)
              // ���ݷ��ص����ݴ�����¼�ɹ��߼�
              this.$router.push('/main')
            })
            .catch(error => {
              console.error(error.response.data)
              // ���ݷ��صĴ�������¼ʧ���߼�
            })
        } else {
          console.log('Form validation failed')
        }
      })
    }
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(to bottom, #000000, #333333); /* Background gradient from black to dark gray */
}

.login-card {
  width: 400px;
  padding: 20px;
  background-color: #222; /* Semi-transparent black background */
  border-radius: 15px; /* Adding border radius for the card */
  color: white; /* Text color for better contrast */
}

.login-title {
  font-size: 24px;
  margin-bottom: 20px;
  text-align: center;
}
</style>
