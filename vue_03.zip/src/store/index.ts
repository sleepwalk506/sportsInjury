import { createStore } from 'vuex'

const store = createStore({
  state: {
    userData: {},
    sportsRecordsData: []
  },
  mutations: {
    setUser (state, responseData) {
      state.userData = responseData
    },
    setSportsRecords (state, responseData) {
      state.sportsRecordsData = responseData
    }
    // ����mutations
  },
  actions: {
    // ����actions
  }
})

export default store
